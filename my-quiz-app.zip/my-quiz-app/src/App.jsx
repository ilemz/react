import React, { useState } from "react";
import questions from "./questions";
// 💥 .jsx 확장자를 명시합니다.
import Question from "./components/Question.jsx"; 
import QuizResult from "./components/QuizResult.jsx";
import "./App.css";

function App() {
  // 1. 상태 정의 (useState)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0); // 현재 문제 번호 (인덱스)
  const [score, setScore] = useState(0); // 현재 점수
  const [showScore, setShowScore] = useState(false); // 결과 화면 표시 여부

  // 2. 이벤트 핸들러: 정답 선택 처리 함수
  const handleAnswerClick = (isCorrect) => {
    // 2-1. 정답인 경우 점수 업데이트
    if (isCorrect) {
      // 스프레드 연산자 대신, setScore 함수에서 이전 상태를 안전하게 업데이트
      setScore(prevScore => prevScore + 1);
    }

    // 2-2. 다음 문제로 이동
    const nextQuestionIndex = currentQuestionIndex + 1;

    // 퀴즈 종료 여부 결정
    if (nextQuestionIndex < questions.length) {
      setCurrentQuestionIndex(nextQuestionIndex);
    } else {
      setShowScore(true);
    }
  };

  // 3. 이벤트 핸들러: 퀴즈 재시작 함수
  const handleRestart = () => {
    // 모든 상태를 초기값으로 리셋
    setCurrentQuestionIndex(0);
    setScore(0);
    setShowScore(false);
  };

  // 4. 렌더링 로직
  return (
    <div className='app'>
      {/* 💥 프로젝트 이름: my-quizz-app 적용 */}
      <h1>My Quizz App</h1> 
      
      {showScore ? (
        // 결과 화면
        <QuizResult 
          score={score} 
          totalQuestions={questions.length} 
          handleRestart={handleRestart}
        />
      ) : (
        // 질문 화면
        <Question 
          question={questions[currentQuestionIndex]} 
          handleAnswerClick={handleAnswerClick} 
        />
      )}
      
      {/* 퀴즈 진행 상태 표시 */}
      {!showScore && (
        <div className='progress-section'>
          문제 {currentQuestionIndex + 1} / {questions.length}
        </div>
      )}
    </div>
  );
}

export default App;