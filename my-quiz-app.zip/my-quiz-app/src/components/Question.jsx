// src/components/Question.jsx
import React from 'react';

// Question 컴포넌트는 현재 질문 데이터와 사용자의 응답을 처리할 함수를 props로 받습니다.
const Question = ({ question, handleAnswerClick }) => {
  // question 객체를 구조분해할당하여 사용
  const { questionText, answerOptions } = question;

  return (
    <div className='question-section'>
      {/* 1. 질문 텍스트 영역 */}
      <div className='question-text'>{questionText}</div>
      
      {/* 2. 응답 선택지 영역 */}
      <div className='answer-section'>
        {/* answerOptions 배열을 map 함수로 순회 */}
        {answerOptions.map((option) => (
          <button 
            key={option.id} 
            // 클릭 시 isCorrect 값을 부모 함수로 전달
            onClick={() => handleAnswerClick(option.isCorrect)}
          >
            {option.answerText}
          </button>
        ))}
      </div>
    </div>
  );
};

export default Question;