// src/components/QuizResult.jsx
import React from 'react';

// QuizResult 컴포넌트는 최종 점수와 퀴즈 재시작 함수를 props로 받습니다.
const QuizResult = ({ score, totalQuestions, handleRestart }) => {
  // 구조분해할당을 사용하여 props를 간결하게 사용합니다.
  const percentage = (score / totalQuestions) * 100;

  return (
    <div className='score-section'>
      {/* 1. 점수 표시 */}
      <h2>퀴즈 종료!</h2>
      <p>
        총 {totalQuestions} 문제 중 
        <span className='score-count'> {score}</span>개를 맞췄습니다.
      </p>
      <p>정답률: {percentage.toFixed(0)}%</p> {/* 정답률 계산 */}
      
      {/* 2. 재시작 버튼 */}
      <button onClick={handleRestart}>다시 시작</button>
    </div>
  );
};

export default QuizResult;