// src/questions.js

const questions = [
  {
    id: 1,
    questionText: 'React에서 상태(State)를 관리하는 가장 기본적인 Hook은 무엇인가요?',
    answerOptions: [
      { id: 1, answerText: 'useRef', isCorrect: false },
      { id: 2, answerText: 'useState', isCorrect: true },
      { id: 3, answerText: 'useEffect', isCorrect: false },
      { id: 4, answerText: 'useContext', isCorrect: false },
    ],
  },
  {
    id: 2,
    questionText: '컴포넌트가 마운트되거나 업데이트될 때마다 부수 효과(Side Effects)를 실행하도록 해주는 Hook은 무엇인가요?',
    answerOptions: [
      { id: 1, answerText: 'useState', isCorrect: false },
      { id: 2, answerText: 'useReducer', isCorrect: false },
      { id: 3, answerText: 'useEffect', isCorrect: true },
      { id: 4, answerText: 'useMemo', isCorrect: false },
    ],
  },
  {
    id: 3,
    questionText: '부모 컴포넌트에서 자식 컴포넌트로 데이터를 전달하는 방법은 무엇인가요?',
    answerOptions: [
      { id: 1, answerText: 'State', isCorrect: false },
      { id: 2, answerText: 'Ref', isCorrect: false },
      { id: 3, answerText: 'Props', isCorrect: true },
      { id: 4, answerText: 'Hook', isCorrect: false },
    ],
  },
];

export default questions;